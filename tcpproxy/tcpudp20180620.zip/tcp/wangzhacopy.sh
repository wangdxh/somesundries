#!/bin/bash

while true
do
    mv %s/*.dat  %s
    mv %s/*.dat  %s
    sleep 0.005
done
