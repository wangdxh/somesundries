#!/bin/sh
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
echo $DIR

useradd ftptest
echo 'kedacom' | passwd --stdin ftptest

/bin/cp -f ./start*.sh /opt/http_proxy/
chmod -R 777 /opt/http_proxy/*
chown -R ftptest:ftptest /opt/http_proxy/*
chmod -R +s /opt/http_proxy/*

#/bin/mv /etc/vsftpd/vsftpd.conf /etc/vsftpd/vsftpd.conf.wangzha.bak
/bin/cp -f ./vsftpd.conf /etc/vsftpd/vsftpd.conf


if grep 'sh /opt/http_proxy/startallclient.sh' /etc/crontab > /dev/null
then
    echo 'startallclient had in etc crontab'
else
    sed -i '$a\ */1 * * * * root sh /opt/http_proxy/startallclient.sh' /etc/crontab
fi


if grep 'sh /opt/http_proxy/startallserver.sh' /etc/crontab > /dev/null
then
    echo 'startallcserver had in etc crontab'
else
    sed -i '$a\ */1 * * * * root sh /opt/http_proxy/startallserver.sh' /etc/crontab
fi

service vsftpd restart

# is crond installed
service crond restart

#/bin/cp -fr ./lib/*.so /usr/lib/usbkeylicense
#/bin/cp -fr ./lib64/*.so /usr/lib64/usbkeylicense
#ldconfig

#/bin/cp -rf ./libusbkey /usr/lib/
#ldconfig /usr/lib/libusbkey/lib64

